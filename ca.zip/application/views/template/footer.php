	</div> <!-- /cols -->

	<!-- Footer -->
	<div id="footer" class="box">

		<p class="f-left">&copy; 2014 <a href="#"> Company Name</a>, All Rights Reserved &reg;</p>

	</div> <!-- /footer -->

</div> <!-- /main -->

</body>
</html>