<?php

echo $msg;

?>